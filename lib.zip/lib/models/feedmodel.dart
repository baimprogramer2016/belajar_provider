import 'package:flutter/foundation.dart';

class FeedModel with ChangeNotifier {
  String? id;
  String? title;
  String? imgUrl;
  bool? isFavorite;

  FeedModel({
    this.id,
    this.title = "Like This",
    this.imgUrl,
    this.isFavorite = false,
  });

  void addFavorite() {
    isFavorite = !isFavorite!;

    title = (isFavorite == true) ? "Unlike This" : "Like This";

    notifyListeners();
  }
}
