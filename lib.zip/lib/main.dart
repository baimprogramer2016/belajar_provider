import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:provider_favorite/models/feedmodel.dart';
import 'package:provider_favorite/providers/feedprovider.dart';
import 'package:provider_favorite/screens/detail.dart';
import './screens/homepage.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => FeedProvider(),
        ),
        ChangeNotifierProvider(
          create: (context) => FeedModel(),
        ),
      ],
      child: MaterialApp(
        routes: {
          DetailPage.routeName: (context) => const DetailPage(),
        },
        home: HomePage(),
      ),
    );
  }
}
