import 'package:flutter/material.dart';
import '../models/feedmodel.dart';

class FeedProvider with ChangeNotifier {
  // ignore: prefer_final_fields
  List<FeedModel> _loadFeeds = List.generate(25, (index) {
    return FeedModel(
      id: index.toString(),
      imgUrl: "https://picsum.photos/id/${index}/200/300/?blur=2".toString(),
    );
  });

  List<FeedModel> get loadFeeds {
    return _loadFeeds;
  }

  FeedModel findById(feedId) {
    return _loadFeeds.firstWhere((element) => element.id == feedId);
  }
}
