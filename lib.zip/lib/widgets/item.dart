import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:provider_favorite/models/feedmodel.dart';
import 'package:provider_favorite/screens/detail.dart';
import '../providers/feedprovider.dart';

class ItemWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final datafeeds = Provider.of<FeedModel>(context);

    return ClipRRect(
        borderRadius: BorderRadius.circular(5),
        child: Stack(
          children: [
            Container(
              width: double.infinity,
              height: double.infinity,
              color: Colors.amber,
              child: Image.network(
                datafeeds.imgUrl ?? '',
                fit: BoxFit.cover,
              ),
            ),
            Container(
              height: double.infinity,
              width: double.infinity,
              color: Colors.grey.withOpacity(0.4),
              child: Consumer<FeedModel>(
                builder: (context, value, child) => IconButton(
                  onPressed: () {
                    value.addFavorite();
                  },
                  icon: (value.isFavorite ?? false)
                      ? const Icon(
                          Icons.favorite,
                          size: 70,
                          color: Color.fromARGB(255, 220, 18, 18),
                        )
                      : Icon(
                          Icons.favorite,
                          size: 70,
                          color: Colors.grey.withOpacity(0.8),
                        ),
                ),
              ),
            ),
            Positioned(
              top: 100.0,
              child: Container(
                color: Colors.deepPurple,
                height: 30.0,
                width: 100.0,
                child: Center(
                  child: Consumer<FeedModel>(
                    builder: (context, value, child) => Text(
                      datafeeds.title ?? '',
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              top: 100.0,
              right: 0.0,
              child: GestureDetector(
                onTap: () {
                  Navigator.of(context)
                      .pushNamed(DetailPage.routeName, arguments: datafeeds.id);
                },
                child: Container(
                  color: Colors.blue,
                  height: 30.0,
                  width: 100.0,
                  child: const Center(
                    child: Text(
                      "Go Detail",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ),
            )
          ],
        ));
  }
}
