import 'package:flutter/material.dart';
import 'package:provider_favorite/widgets/item.dart';
import 'package:provider/provider.dart';
import '../providers/feedprovider.dart';

class GridWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final feedsdata = Provider.of<FeedProvider>(context);
    final allfeed = feedsdata.loadFeeds;

    return GridView.builder(
      padding: const EdgeInsets.all(10),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 3 / 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
      ),
      itemCount: allfeed.length,
      itemBuilder: (context, index) => ChangeNotifierProvider.value(
        value: allfeed[index],
        child: ItemWidget(),
      ),
    );
  }
}
