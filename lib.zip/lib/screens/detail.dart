import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:provider_favorite/models/feedmodel.dart';
import 'package:provider_favorite/providers/feedprovider.dart';

class DetailPage extends StatelessWidget {
  static const routeName = '/detail';

  const DetailPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final id = ModalRoute.of(context)?.settings.arguments;
    final datadetail = Provider.of<FeedProvider>(context).findById(id);

    return Scaffold(
      appBar: AppBar(title: const Text('Detail')),
      body: Column(
        children: [
          SizedBox(
            height: 300,
            width: double.infinity,
            child: Image.network(
              datadetail.imgUrl.toString(),
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(
            height: 40,
          ),
          SizedBox(
            width: double.infinity,
            height: 100,
            child: Consumer<FeedModel>(
              builder: (context, value, child) => IconButton(
                icon: (datadetail.isFavorite ?? false)
                    ? Icon(
                        Icons.favorite,
                        size: 70,
                        color: Color.fromARGB(255, 220, 18, 18),
                      )
                    : Icon(
                        Icons.favorite,
                        size: 70,
                        color: Colors.grey.withOpacity(0.8),
                      ),
                onPressed: () {
                  datadetail.addFavorite();
                },
              ),
            ),
          ),
          Center(
            child: Text(
              "${datadetail.title}",
              style: TextStyle(fontSize: 35),
            ),
          )
        ],
      ),
    );
  }
}
